﻿///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var Keyboard = (function () {
        function Keyboard() {
            this.keysDown = [];
            this.keysPressed = [];
            document.addEventListener('keydown', this.keyDown.bind(this), false);
            document.addEventListener('keyup', this.keyUp.bind(this), false);
        }
        Keyboard.prototype.update = function () {
            this.keysPressed = [];
        };

        Keyboard.prototype.keyDown = function (event) {
            if (this.keysDown.indexOf(event.keyCode) == -1) {
                this.keysDown.push(event.keyCode);
            }
        };

        Keyboard.prototype.keyUp = function (event) {
            this.keysPressed.push(event.keyCode);
            var index = this.keysDown.indexOf(event.keyCode, 0);
            if (index != undefined) {
                this.keysDown.splice(index, 1);
            }
        };

        Keyboard.prototype.isKeyDown = function (key) {
            return this.keysDown.indexOf(key) != -1;
        };

        Keyboard.prototype.isKeyPressed = function (key) {
            return this.keysPressed.indexOf(key) != -1;
        };
        return Keyboard;
    })();
    eVOCus.Keyboard = Keyboard;
})(eVOCus || (eVOCus = {}));
