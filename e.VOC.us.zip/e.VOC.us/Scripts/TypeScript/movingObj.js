﻿///<reference path='SpriteObject.ts' />
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var eVOCus;
(function (eVOCus) {
    var movingObj = (function (_super) {
        __extends(movingObj, _super);
        function movingObj(name, position, id, image, speed, direction) {
            _super.call(this, name, position, id, image);
            this.image = image;
            this.speed = speed;
            this.direction = direction;
            this.setSpeed(speed);
            this.setDirection(direction);
        }
        movingObj.prototype.getSpeed = function () {
            return this.speed;
        };

        movingObj.prototype.setSpeed = function (s) {
            this.speed = s;
        };

        movingObj.prototype.getDirection = function () {
            return this.direction;
        };

        movingObj.prototype.setDirection = function (d) {
            this.direction = d;
        };

        movingObj.prototype.draw = function (context, gameTime) {
            context.drawImage(this.image, this.position.x, this.position.y);
        };
        return movingObj;
    })(eVOCus.SpriteObject);
    eVOCus.movingObj = movingObj;
})(eVOCus || (eVOCus = {}));
