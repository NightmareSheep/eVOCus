﻿var eVOCus;
(function (eVOCus) {
    var Rectangle = (function () {
        function Rectangle(x, y, width, height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
        Rectangle.prototype.contains = function (v) {
            if (v.x > this.x && v.x < this.x + this.width && v.y > this.y && v.y < this.y + this.height)
                return true;
            return false;
        };
        return Rectangle;
    })();
    eVOCus.Rectangle = Rectangle;
})(eVOCus || (eVOCus = {}));
