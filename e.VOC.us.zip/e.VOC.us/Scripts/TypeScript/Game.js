﻿var eVOCus;
(function (eVOCus) {
    var Game = (function () {
        function Game() {
            var _this = this;
            this.fps = 60;
            this.gameTime = 0;
            Game.keyboard = new eVOCus.Keyboard();
            this.canvas = new eVOCus.Canvas();
            this.timeStep = Math.floor(1000 / this.fps);

            var image = new Image();
            image.src = "../Assets/PirateShip.png";
            this.ship = new eVOCus.Ship(0, 5, new eVOCus.RotatableRectangle(new eVOCus.Vector2D(180, 60), 360, 120, 0), image);

            // current speed, max speed, vector position, img width/height, angle
            setInterval(function () {
                _this.gameLoop(_this);
            }, this.timeStep);
        }
        Game.prototype.gameLoop = function (gameObject) {
            this.gameTime += this.timeStep;
            this.update(this.gameTime);
            this.draw(this.canvas);
        };

        Game.prototype.update = function (gameTime) {
            this.canvas.ctx.clearRect(0, 0, 2000, 2000);
            this.ship.update(gameTime);
            Game.keyboard.update();
        };

        Game.prototype.draw = function (canvas) {
            this.ship.draw(canvas);
        };
        return Game;
    })();
    eVOCus.Game = Game;
})(eVOCus || (eVOCus = {}));
