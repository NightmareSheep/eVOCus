﻿///<reference path='RotatableSpriteObject.ts' />
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var eVOCus;
(function (eVOCus) {
    var Ship = (function (_super) {
        __extends(Ship, _super);
        //get maxSpeed(): number { return this._maxSpeed; }
        //set maxSpeed(value: number) { this._maxSpeed = value; this.speed = this._speed; }
        function Ship(speed, maxSpeed, rectangle, image) {
            _super.call(this, rectangle, image);
            this.rectangle = rectangle;

            //this.maxSpeed = maxSpeed;
            //this.speed = speed;
            this.setMaxSpeed(maxSpeed);
            this.setSpeed(speed);
        }
        Ship.prototype.update = function (gameTime) {
            // speed en angle aanpassen
            if (eVOCus.Game.keyboard.isKeyDown(37))
                this.rectangle.angle--;
            if (eVOCus.Game.keyboard.isKeyDown(38))
                this.setSpeed(this.getSpeed() + 1);
            if (eVOCus.Game.keyboard.isKeyDown(39))
                this.rectangle.angle++;
            if (eVOCus.Game.keyboard.isKeyDown(40))
                this.setSpeed(this.getSpeed() - 1);

            // angle tussen 0 en 360 graden houden
            if (this.rectangle.angle < 0)
                this.rectangle.angle += 360;
            if (this.rectangle.angle > 359)
                this.rectangle.angle -= 360;

            // Binnen canvas blijven
            if (this.rectangle.hitsBorder())
                this.setSpeed(0);

            // positie aanpassen
            this.rectangle.position.add(eVOCus.Helper.angleToUnitVector(this.rectangle.angle).multiply(this.getSpeed()));
        };

        Ship.prototype.draw = function (canvas) {
            _super.prototype.draw.call(this, canvas, 0);
        };

        Ship.prototype.getSpeed = function () {
            return this._speed;
        };

        Ship.prototype.setSpeed = function (value) {
            if (value > 0)
                this._speed = Math.min(this.getMaxSpeed(), value);
            else
                this._speed = 0;
        };

        Ship.prototype.getMaxSpeed = function () {
            return this._maxSpeed;
        };

        Ship.prototype.setMaxSpeed = function (value) {
            this._maxSpeed = value;
            this.setSpeed(this._speed);
        };
        return Ship;
    })(eVOCus.RotatableSpriteObject);
    eVOCus.Ship = Ship;
})(eVOCus || (eVOCus = {}));
