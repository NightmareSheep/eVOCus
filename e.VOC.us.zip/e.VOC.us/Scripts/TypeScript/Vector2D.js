﻿var eVOCus;
(function (eVOCus) {
    var Vector2D = (function () {
        function Vector2D(x, y) {
            this.x = x;
            this.y = y;
        }
        Vector2D.prototype.add = function (vector) {
            this.x += vector.x;
            this.y += vector.y;
            return this;
        };

        Vector2D.prototype.multiply = function (i) {
            this.x *= i;
            this.y *= i;
            return this;
        };
        return Vector2D;
    })();
    eVOCus.Vector2D = Vector2D;
})(eVOCus || (eVOCus = {}));
