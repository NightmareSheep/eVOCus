﻿///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var Canvas = (function () {
        function Canvas() {
            var canvas = document.getElementById("canvas");
            canvas.width = 2000;
            canvas.height = 2000;
            this.ctx = canvas.getContext("2d");
        }
        Canvas.prototype.drawRotatableImage = function (image, rotatableRectangle) {
            this.ctx.translate(rotatableRectangle.position.x, rotatableRectangle.position.y);
            this.ctx.rotate(rotatableRectangle.angle * (Math.PI / 180));
            this.ctx.drawImage(image, -rotatableRectangle.width / 2, -rotatableRectangle.height / 2);
            this.ctx.rotate(-rotatableRectangle.angle * (Math.PI / 180));
            this.ctx.translate(-rotatableRectangle.position.x, -rotatableRectangle.position.y);
        };
        return Canvas;
    })();
    eVOCus.Canvas = Canvas;
})(eVOCus || (eVOCus = {}));
