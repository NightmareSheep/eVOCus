﻿var eVOCus;
(function (eVOCus) {
    var GameObject = (function () {
        function GameObject(name, position, id) {
            this.name = name;
            this.position = position;
            this.id = id;
            this.setPosition(position);
        }
        GameObject.prototype.getPosition = function () {
            return this.position;
        };

        GameObject.prototype.setPosition = function (p) {
            this.position.x = p.x;
            this.position.y = p.y;
        };

        GameObject.prototype.update = function (gameTime) {
        };

        GameObject.prototype.draw = function (context, gameTime) {
        };
        return GameObject;
    })();
    eVOCus.GameObject = GameObject;
})(eVOCus || (eVOCus = {}));
