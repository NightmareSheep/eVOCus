﻿var eVOCus;
(function (eVOCus) {
    var GameObject = (function () {
        function GameObject(name, position, id) {
            this.name = name;
            this.position = position;
            this.id = id;
            this.setPosition(position);
        }
        GameObject.prototype.getPosition = function () {
            return this.position;
        };

        GameObject.prototype.setPosition = function (p) {
            this.position.x = p.x;
            this.position.y = p.y;
        };

        GameObject.prototype.update = function (gameTime) {
        };

        GameObject.prototype.draw = function (context, gameTime) {
        };
        return GameObject;
    })();
    eVOCus.GameObject = GameObject;
})(eVOCus || (eVOCus = {}));
///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var Keyboard = (function () {
        function Keyboard() {
            this.keysDown = [];
            this.keysPressed = [];
            document.addEventListener('keydown', this.keyDown.bind(this), false);
            document.addEventListener('keyup', this.keyUp.bind(this), false);
        }
        Keyboard.prototype.update = function () {
            this.keysPressed = [];
        };

        Keyboard.prototype.keyDown = function (event) {
            if (this.keysDown.indexOf(event.keyCode) == -1) {
                this.keysDown.push(event.keyCode);
            }
        };

        Keyboard.prototype.keyUp = function (event) {
            this.keysPressed.push(event.keyCode);
            var index = this.keysDown.indexOf(event.keyCode, 0);
            if (index != undefined) {
                this.keysDown.splice(index, 1);
            }
        };

        Keyboard.prototype.isKeyDown = function (key) {
            return this.keysDown.indexOf(key) != -1;
        };

        Keyboard.prototype.isKeyPressed = function (key) {
            return this.keysPressed.indexOf(key) != -1;
        };
        return Keyboard;
    })();
    eVOCus.Keyboard = Keyboard;
})(eVOCus || (eVOCus = {}));
///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var Canvas = (function () {
        function Canvas(width, height) {
            this.width = width;
            this.height = height;
            var canvas = document.getElementById("canvas");
            canvas.width = width;
            canvas.height = height;
            this.ctx = canvas.getContext("2d");
        }
        Canvas.prototype.drawRotatableImage = function (image, rotatableRectangle) {
            this.ctx.translate(rotatableRectangle.position.x, rotatableRectangle.position.y);
            this.ctx.rotate(rotatableRectangle.angle * (Math.PI / 180));
            this.ctx.drawImage(image, -rotatableRectangle.width / 2, -rotatableRectangle.height / 2);
            this.ctx.rotate(-rotatableRectangle.angle * (Math.PI / 180));
            this.ctx.translate(-rotatableRectangle.position.x, -rotatableRectangle.position.y);
        };
        return Canvas;
    })();
    eVOCus.Canvas = Canvas;
})(eVOCus || (eVOCus = {}));
///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var Helper = (function () {
        function Helper() {
        }
        Helper.angleToUnitVector = function (angle) {
            return new eVOCus.Vector2D(Math.cos(angle / (180 / Math.PI)), Math.sin(angle / (180 / Math.PI)));
        };
        return Helper;
    })();
    eVOCus.Helper = Helper;
})(eVOCus || (eVOCus = {}));
var eVOCus;
(function (eVOCus) {
    var Rectangle = (function () {
        function Rectangle(x, y, width, height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
        Rectangle.prototype.contains = function (v) {
            if (v.x > this.x && v.x < this.x + this.width && v.y > this.y && v.y < this.y + this.height)
                return true;
            return false;
        };
        return Rectangle;
    })();
    eVOCus.Rectangle = Rectangle;
})(eVOCus || (eVOCus = {}));
///<reference path='Rectangle.ts' />
var eVOCus;
(function (eVOCus) {
    // Rectangle that can rotate with the x and y in the center.
    var RotatableRectangle = (function () {
        function RotatableRectangle(position, width, height, angle) {
            this.position = position;
            this.width = width;
            this.height = height;
            this.angle = angle;
        }
        RotatableRectangle.prototype.hitsBorder = function (canvas) {
            this.calcCorners();

            if (Math.max(this._cornerLV.x, this._cornerRV.x) >= canvas.width && (this.angle > 270 || this.angle < 90))
                return true;
            if (Math.min(this._cornerLV.x, this._cornerRV.x) <= 0 && (this.angle > 90 && this.angle < 270))
                return true;
            if (Math.max(this._cornerLV.y, this._cornerRV.y) >= canvas.height && (this.angle < 180))
                return true;
            if (Math.min(this._cornerLV.y, this._cornerRV.y) <= 0 && (this.angle > 180))
                return true;
            return false;
        };

        RotatableRectangle.prototype.hitsShip = function (num, canvas) {
            this.calcCorners();
            var ships = eVOCus.Game.game.gamestate.ships;

            for (var i = 0; i < ships.length; i++) {
                canvas.ctx.translate(-ships[i].rectangle.position.x, -ships[i].rectangle.position.y);
                canvas.ctx.rotate(-ships[i].rectangle.angle * (Math.PI / 180));

                if (num != ships[i].id) {
                    if (this.cornerHitsShip(this._cornerLV, ships[i].rectangle) || this.cornerHitsShip(this._cornerRV, ships[i].rectangle)) {
                        canvas.ctx.rotate(ships[i].rectangle.angle * (Math.PI / 180));
                        canvas.ctx.translate(ships[i].rectangle.position.x, ships[i].rectangle.position.y);
                        return ships[i].id;
                    }
                }
                canvas.ctx.rotate(ships[i].rectangle.angle * (Math.PI / 180));
                canvas.ctx.translate(ships[i].rectangle.position.x, ships[i].rectangle.position.y);
            }
            return 0;
        };

        RotatableRectangle.prototype.calcCorners = function () {
            this._cornerLV = this.calcCorner(this.width / 2, this.height / -2);
            this._cornerRV = this.calcCorner(this.width / 2, this.height / 2);
            this._cornerLA = this.calcCorner(this.width / -2, this.height / -2);
            this._cornerRA = this.calcCorner(this.width / -2, this.height / 2);
        };

        RotatableRectangle.prototype.calcCorner = function (dX, dY) {
            return new eVOCus.Vector2D(this.position.x + dX * Math.cos(this.angle / 180 * Math.PI) - dY * Math.sin(this.angle / 180 * Math.PI), this.position.y + dX * Math.sin(this.angle / 180 * Math.PI) + dY * Math.cos(this.angle / 180 * Math.PI));
        };

        RotatableRectangle.prototype.cornerHitsShip = function (corner, rectangle) {
            return (corner.x > (rectangle.position.x - rectangle.width / 2) && corner.x < (rectangle.position.x + rectangle.width / 2) && corner.y > (rectangle.position.y - rectangle.height / 2) && corner.y < (rectangle.position.y + rectangle.height / 2));
        };
        return RotatableRectangle;
    })();
    eVOCus.RotatableRectangle = RotatableRectangle;
})(eVOCus || (eVOCus = {}));
///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var RotatableSpriteObject = (function () {
        function RotatableSpriteObject(rectangle, image) {
            this.rectangle = rectangle;
            this.image = image;
        }
        RotatableSpriteObject.prototype.draw = function (canvas, gameTime) {
            canvas.drawRotatableImage(this.image, this.rectangle);
        };
        return RotatableSpriteObject;
    })();
    eVOCus.RotatableSpriteObject = RotatableSpriteObject;
})(eVOCus || (eVOCus = {}));
///<reference path='RotatableSpriteObject.ts' />
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var eVOCus;
(function (eVOCus) {
    var Ship = (function (_super) {
        __extends(Ship, _super);
        //get maxSpeed(): number { return this._maxSpeed; }
        //set maxSpeed(value: number) { this._maxSpeed = value; this.speed = this._speed; }
        function Ship(id, speed, maxSpeed, rectangle, image) {
            _super.call(this, rectangle, image);
            this.id = id;
            this.rectangle = rectangle;

            //this.maxSpeed = maxSpeed;
            //this.speed = speed;
            this.setMaxSpeed(maxSpeed);
            this.setSpeed(speed);
        }
        Ship.prototype.update = function (canvas, gameTime) {
            // speed en angle aanpassen
            if (this.id == 4001) {
                if (eVOCus.Game.keyboard.isKeyDown(37))
                    this.rectangle.angle--;
                if (eVOCus.Game.keyboard.isKeyDown(38))
                    this.setSpeed(this.getSpeed() + 1);
                if (eVOCus.Game.keyboard.isKeyDown(39))
                    this.rectangle.angle++;
                if (eVOCus.Game.keyboard.isKeyDown(40))
                    this.setSpeed(this.getSpeed() - 1);
                if (eVOCus.Game.keyboard.isKeyPressed(13)) {
                    var image = new Image();
                    var canonball;
                    image.src = "../Assets/cannonball.png";
                    canonball = new eVOCus.CanonBall((this.id + gameTime), 10, new eVOCus.RotatableRectangle(this.rectangle.calcCorner(this.rectangle.width / 2, 0), 50, 50, this.rectangle.angle), image);
                    eVOCus.Game.game.gamestate.addCanonball(canonball);
                }
            }

            if (this.id == 8007) {
                if (eVOCus.Game.keyboard.isKeyDown(65))
                    this.rectangle.angle--;
                if (eVOCus.Game.keyboard.isKeyDown(87))
                    this.setSpeed(this.getSpeed() + 1);
                if (eVOCus.Game.keyboard.isKeyDown(68))
                    this.rectangle.angle++;
                if (eVOCus.Game.keyboard.isKeyDown(83))
                    this.setSpeed(this.getSpeed() - 1);
                if (eVOCus.Game.keyboard.isKeyPressed(70)) {
                    var image = new Image();
                    var canonball;
                    image.src = "../Assets/cannonball.png";
                    canonball = new eVOCus.CanonBall((this.id + gameTime), 10, new eVOCus.RotatableRectangle(this.rectangle.calcCorner(this.rectangle.width / 2, 0), 50, 50, this.rectangle.angle), image);
                    eVOCus.Game.game.gamestate.addCanonball(canonball);
                }
            }

            // angle tussen 0 en 360 graden houden
            if (this.rectangle.angle < 0)
                this.rectangle.angle += 360;
            if (this.rectangle.angle > 359)
                this.rectangle.angle -= 360;

            // Binnen canvas blijven
            if (this.rectangle.hitsBorder(canvas))
                this.setSpeed(0);

            // Ander schip raken
            if (this.rectangle.hitsShip(this.id, canvas) != 0)
                this.setSpeed(0);

            // positie aanpassen
            this.rectangle.position.add(eVOCus.Helper.angleToUnitVector(this.rectangle.angle).multiply(this.getSpeed()));
        };

        Ship.prototype.draw = function (canvas) {
            _super.prototype.draw.call(this, canvas, 0);
        };

        Ship.prototype.getSpeed = function () {
            return this._speed;
        };

        Ship.prototype.setSpeed = function (value) {
            if (value > 0)
                this._speed = Math.min(this.getMaxSpeed(), value);
            else
                this._speed = 0;
        };

        Ship.prototype.getMaxSpeed = function () {
            return this._maxSpeed;
        };

        Ship.prototype.setMaxSpeed = function (value) {
            this._maxSpeed = value;
            this.setSpeed(this._speed);
        };
        return Ship;
    })(eVOCus.RotatableSpriteObject);
    eVOCus.Ship = Ship;
})(eVOCus || (eVOCus = {}));
var eVOCus;
(function (eVOCus) {
    var Vector2D = (function () {
        function Vector2D(x, y) {
            this.x = x;
            this.y = y;
        }
        Vector2D.prototype.add = function (vector) {
            this.x += vector.x;
            this.y += vector.y;
            return this;
        };

        Vector2D.prototype.multiply = function (i) {
            this.x *= i;
            this.y *= i;
            return this;
        };
        return Vector2D;
    })();
    eVOCus.Vector2D = Vector2D;
})(eVOCus || (eVOCus = {}));
///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var SpriteObject = (function (_super) {
        __extends(SpriteObject, _super);
        function SpriteObject(name, position, id, image) {
            _super.call(this, name, position, id);
            this.image = image;
        }
        SpriteObject.prototype.draw = function (context, gameTime) {
            context.drawImage(this.image, this.position.x, this.position.y);
        };

        SpriteObject.prototype.overlaps = function (object) {
            return (this.position.y + this.image.height > object.position.y && this.position.y < object.position.y + object.image.height && this.position.x + this.image.width > object.position.x && this.position.x < object.position.x + object.image.width);
        };
        return SpriteObject;
    })(eVOCus.GameObject);
    eVOCus.SpriteObject = SpriteObject;
})(eVOCus || (eVOCus = {}));
var eVOCus;
(function (eVOCus) {
    var GameState = (function () {
        function GameState(ships, canonBalls) {
            this.ships = ships;
            this.canonBalls = canonBalls;
        }
        GameState.prototype.update = function (canvas, gameTime) {
            for (var i = 0; i < this.ships.length; i++) {
                //console.log('in for loop, i = ' + i);
                this.ships[i].update(canvas, gameTime);
            }

            for (var i = 0; i < this.canonBalls.length; i++) {
                //console.log('in for loop, i = ' + i);
                this.canonBalls[i].update(canvas, gameTime);
            }
        };

        GameState.prototype.draw = function (canvas) {
            for (var i = 0; i < this.ships.length; i++) {
                this.ships[i].draw(canvas);
            }
            for (var i = 0; i < this.canonBalls.length; i++) {
                this.canonBalls[i].draw(canvas);
            }
        };

        GameState.prototype.addShip = function (ship) {
            this.ships[this.ships.length] = ship;
        };

        GameState.prototype.addCanonball = function (ball) {
            this.canonBalls[this.canonBalls.length] = ball;
        };

        GameState.prototype.removeCanonball = function (ballID) {
            for (var i = 0; i < this.canonBalls.length; i++) {
                if (this.canonBalls[i].id == ballID) {
                    this.canonBalls.splice(i, 1);
                }
            }
        };

        GameState.prototype.removeShip = function (shipID) {
            for (var i = 0; i < this.ships.length; i++) {
                if (this.ships[i].id == shipID) {
                    this.ships.splice(i, 1);
                }
            }
        };
        return GameState;
    })();
    eVOCus.GameState = GameState;
})(eVOCus || (eVOCus = {}));
///<reference path='RotatableSpriteObject.ts' />
var eVOCus;
(function (eVOCus) {
    var CanonBall = (function (_super) {
        __extends(CanonBall, _super);
        function CanonBall(id, speed, rectangle, image) {
            _super.call(this, rectangle, image);
            this.id = id;
            this.rectangle = rectangle;
            this.setSpeed(speed);
        }
        CanonBall.prototype.update = function (canvas, gameTime) {
            // Buiten canvas verdwijnen
            if (this.rectangle.hitsBorder(canvas)) {
                eVOCus.Game.game.gamestate.removeCanonball(this.id);
            }

            // Ander object raken
            var hit = this.rectangle.hitsShip(this.id, canvas);
            if (hit != 0) {
                eVOCus.Game.game.gamestate.removeCanonball(this.id);
                eVOCus.Game.game.gamestate.removeShip(hit);
            }

            // positie aanpassen
            this.rectangle.position.add(eVOCus.Helper.angleToUnitVector(this.rectangle.angle).multiply(this.getSpeed()));
        };

        CanonBall.prototype.draw = function (canvas) {
            _super.prototype.draw.call(this, canvas, 0);
        };

        CanonBall.prototype.getSpeed = function () {
            return this._speed;
        };

        CanonBall.prototype.setSpeed = function (value) {
            this._speed = value;
        };
        return CanonBall;
    })(eVOCus.RotatableSpriteObject);
    eVOCus.CanonBall = CanonBall;
})(eVOCus || (eVOCus = {}));
var eVOCus;
(function (eVOCus) {
    var Game = (function () {
        function Game() {
            var _this = this;
            this.fps = 60;
            this.gameTime = 0;
            Game.game = this;
            Game.keyboard = new eVOCus.Keyboard();
            this.canvas = new eVOCus.Canvas(3000, 2400);
            this.timeStep = Math.floor(1000 / this.fps);

            var image = new Image();
            image.src = "../Assets/PirateShip.png";
            this.ship = new eVOCus.Ship(4001, 0, 5, new eVOCus.RotatableRectangle(new eVOCus.Vector2D(180, 60), 360, 120, 0), image);
            this.ship2 = new eVOCus.Ship(8007, 0, 5, new eVOCus.RotatableRectangle(new eVOCus.Vector2D(180, 600), 360, 120, 0), image);

            // current speed, max speed, vector position, img width/height, angle
            this.getGameState();

            setInterval(function () {
                _this.gameLoop(_this);
            }, this.timeStep);
        }
        Game.prototype.gameLoop = function (gameObject) {
            this.gameTime += this.timeStep;

            //this.getGameState();
            this.update(this.gameTime);
            this.draw(this.canvas);
        };

        Game.prototype.update = function (gameTime) {
            this.canvas.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
            this.gamestate.update(this.canvas, gameTime);
            Game.keyboard.update();
        };

        Game.prototype.getGameState = function () {
            // Gamestate van server ophalen / ontvangen
            //this.gamestate = new GameState([this.ship, this.ship2], []);
            this.gamestate = new eVOCus.GameState([], []);
            this.gamestate.addShip(this.ship);
            this.gamestate.addShip(this.ship2);
        };

        Game.prototype.draw = function (canvas) {
            //this.ship.draw(canvas);
            this.gamestate.draw(canvas);
        };
        return Game;
    })();
    eVOCus.Game = Game;
})(eVOCus || (eVOCus = {}));
var eVOCus;
(function (eVOCus) {
    var game;

    window.onload = function () {
        game = new eVOCus.Game();
    };
})(eVOCus || (eVOCus = {}));
