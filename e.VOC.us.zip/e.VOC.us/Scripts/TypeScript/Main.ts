﻿module eVOCus {
    var game: Game;

     window.onload = () => {
         game = new Game();
     }
 }