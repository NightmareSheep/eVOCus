﻿///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var RotatableSpriteObject = (function () {
        function RotatableSpriteObject(rectangle, image) {
            this.rectangle = rectangle;
            this.image = image;
        }
        RotatableSpriteObject.prototype.draw = function (canvas, gameTime) {
            canvas.drawRotatableImage(this.image, this.rectangle);
        };
        return RotatableSpriteObject;
    })();
    eVOCus.RotatableSpriteObject = RotatableSpriteObject;
})(eVOCus || (eVOCus = {}));
