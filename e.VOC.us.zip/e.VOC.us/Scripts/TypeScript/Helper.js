﻿///<reference path='GameObject.ts' />
var eVOCus;
(function (eVOCus) {
    var Helper = (function () {
        function Helper() {
        }
        Helper.angleToUnitVector = function (angle) {
            return new eVOCus.Vector2D(Math.cos(angle / (180 / Math.PI)), Math.sin(angle / (180 / Math.PI)));
        };
        return Helper;
    })();
    eVOCus.Helper = Helper;
})(eVOCus || (eVOCus = {}));
