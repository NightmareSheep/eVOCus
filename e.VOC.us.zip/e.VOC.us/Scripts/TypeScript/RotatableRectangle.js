﻿///<reference path='Rectangle.ts' />
var eVOCus;
(function (eVOCus) {
    // Rectangle that can rotate with the x and y in the center.
    var RotatableRectangle = (function () {
        function RotatableRectangle(position, width, height, angle) {
            this.position = position;
            this.width = width;
            this.height = height;
            this.angle = angle;
        }
        RotatableRectangle.prototype.hitsBorder = function () {
            var _cornerLV = this.calcCorner(this.width / 2, this.height / -2);
            var _cornerRV = this.calcCorner(this.width / 2, this.height / 2);

            if (Math.max(_cornerLV.x, _cornerRV.x) >= 2000 && (this.angle > 270 || this.angle < 90))
                return true;
            if (Math.min(_cornerLV.x, _cornerRV.x) <= 0 && (this.angle > 90 && this.angle < 270))
                return true;
            if (Math.max(_cornerLV.y, _cornerRV.y) >= 2000 && (this.angle < 180))
                return true;
            if (Math.min(_cornerLV.y, _cornerRV.y) <= 0 && (this.angle > 180))
                return true;
            return false;
        };

        RotatableRectangle.prototype.calcCorner = function (dX, dY) {
            return new eVOCus.Vector2D(this.position.x + dX * Math.cos(this.angle / 180 * Math.PI) - dY * Math.sin(this.angle / 180 * Math.PI), this.position.y + dX * Math.sin(this.angle / 180 * Math.PI) + dY * Math.cos(this.angle / 180 * Math.PI));
        };
        return RotatableRectangle;
    })();
    eVOCus.RotatableRectangle = RotatableRectangle;
})(eVOCus || (eVOCus = {}));
