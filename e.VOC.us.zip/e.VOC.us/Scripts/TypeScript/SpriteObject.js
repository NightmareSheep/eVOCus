﻿///<reference path='GameObject.ts' />
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var eVOCus;
(function (eVOCus) {
    var SpriteObject = (function (_super) {
        __extends(SpriteObject, _super);
        function SpriteObject(name, position, id, image) {
            _super.call(this, name, position, id);
            this.image = image;
        }
        SpriteObject.prototype.draw = function (context, gameTime) {
            context.drawImage(this.image, this.position.x, this.position.y);
        };

        SpriteObject.prototype.overlaps = function (object) {
            return (this.position.y + this.image.height > object.position.y && this.position.y < object.position.y + object.image.height && this.position.x + this.image.width > object.position.x && this.position.x < object.position.x + object.image.width);
        };
        return SpriteObject;
    })(eVOCus.GameObject);
    eVOCus.SpriteObject = SpriteObject;
})(eVOCus || (eVOCus = {}));
