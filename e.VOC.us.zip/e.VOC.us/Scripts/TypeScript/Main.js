﻿var eVOCus;
(function (eVOCus) {
    var game;

    window.onload = function () {
        game = new eVOCus.Game();
    };
})(eVOCus || (eVOCus = {}));
