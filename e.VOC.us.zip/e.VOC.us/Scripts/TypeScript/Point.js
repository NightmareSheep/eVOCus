﻿var eVOCus;
(function (eVOCus) {
    var Point = (function () {
        function Point(x, y) {
            this.x = x;
            this.y = y;
        }
        return Point;
    })();
    eVOCus.Point = Point;
})(eVOCus || (eVOCus = {}));
